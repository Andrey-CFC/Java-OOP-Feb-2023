package L05Inheritance.P01SingleInheritance;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        Animal animal = new Animal();
        animal.eat();
        Dog dog = new Dog();
        dog.bark();
        dog.eat();
    }
}
