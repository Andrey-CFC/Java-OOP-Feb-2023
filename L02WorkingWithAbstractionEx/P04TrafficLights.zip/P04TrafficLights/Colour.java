package L02WorkingWithAbstractionEx.P04TrafficLights;

public enum Colour {
    RED,
    YELLOW,
    GREEN;
}
