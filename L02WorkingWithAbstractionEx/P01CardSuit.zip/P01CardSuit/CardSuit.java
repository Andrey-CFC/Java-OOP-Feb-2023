package L02WorkingWithAbstractionEx.P01CardSuit;

public enum CardSuit {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
